Programmer: Oliver Thompson

This code was compiled with the:

cl /EHsc main.cpp

command line in the Visual Studio developer command line and
run through the Visual Studio developer command line.

This program was created for a class focused on object oriented
analysis and design.  The program replicates the interaction of a physical
room, a thermostat, and an air conditioning unit.

The purpose is to demonstrate control flow through various user defined
classes and functions.